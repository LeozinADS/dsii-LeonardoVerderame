import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Calculator calculator = new Calculator();

        System.out.println("Bem-vindo à Calculadora Alpha!");

        while (true) {
            System.out.println("\nEscolha uma opção:");
            System.out.println("1. Operações Básicas");
            System.out.println("2. Raiz Quadrada");
            System.out.println("3. Signo Zodiacal");
            System.out.println("4. Sair");
            System.out.print("Opção: ");

            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Digite o primeiro número: ");
                    double num1 = scanner.nextDouble();
                    System.out.print("Digite o segundo número: ");
                    double num2 = scanner.nextDouble();
                    System.out.print("Escolha a operação (+, -, *, /): ");
                    String operation = scanner.next();

                    try {
                        double result = 0;
                        switch (operation) {
                            case "+":
                                result = calculator.add(num1, num2);
                                break;
                            case "-":
                                result = calculator.subtract(num1, num2);
                                break;
                            case "*":
                                result = calculator.multiply(num1, num2);
                                break;
                            case "/":
                                result = calculator.divide(num1, num2);
                                break;
                            default:
                                System.out.println("Operação inválida.");
                                continue;
                        }
                        System.out.println("Resultado: " + result);
                    } catch (IllegalArgumentException e) {
                        System.out.println("Erro: " + e.getMessage());
                    }
                    break;
                case 2:
                    System.out.print("Digite o número para calcular a raiz quadrada: ");
                    double num = scanner.nextDouble();
                    try {
                        double result = calculator.squareRoot(num);
                        System.out.println("Raiz Quadrada: " + result);
                    } catch (IllegalArgumentException e) {
                        System.out.println("Erro: " + e.getMessage());
                    }
                    break;
                case 3:
                    System.out.print("Digite o dia de nascimento (1-31): ");
                    int day = scanner.nextInt();
                    System.out.print("Digite o mês de nascimento (1-12): ");
                    int month = scanner.nextInt();
                    try {
                        String zodiacSign = calculator.getZodiacSign(day, month);
                        System.out.println("Seu signo zodiacal é: " + zodiacSign);
                    } catch (IllegalArgumentException e) {
                        System.out.println("Erro: " + e.getMessage());
                    }
                    break;
                case 4:
                    System.out.println("Saindo da calculadora. Até mais!");
                    scanner.close();
                    return;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
            }
        }
    }
}


