import java.util.Date;

public class EscolaMain {
    public static void main(String[] args) {
        Date dataHoje = new Date(); // Exemplo de data de nascimento/admissão

        Aluno aluno = new Aluno("Maria Silva", "111.111.111-11", dataHoje, "A12345");
        Professor professor = new Professor("João Souza", "222.222.222-22", dataHoje, 4500.00, "Matematica");
        Funcionario funcionario = new Funcionario("Ana Lima", "333.333.333-33", dataHoje, 3000.00, "Secretária", dataHoje);

        int qtdCopias = 100;

        System.out.println("=== Valores das Cópias ===");
        System.out.println("Aluno: " + aluno.nome + " - R$ " + aluno.tirarCopias(qtdCopias));
        System.out.println("Professor: " + professor.nome + " - R$ " + professor.tirarCopias(qtdCopias));
        System.out.println("Funcionario: " + funcionario.nome + " - R$ " + funcionario.tirarCopias(qtdCopias));
    }
}
